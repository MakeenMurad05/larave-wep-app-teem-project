<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\HP\larave-wep-app-teem-project\vendor\filament\widgets\resources\views/components/widget.blade.php ENDPATH**/ ?>